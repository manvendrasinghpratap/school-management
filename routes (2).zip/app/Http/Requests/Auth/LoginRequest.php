<?php

namespace App\Http\Requests\Auth;

use Illuminate\Auth\Events\Lockout;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class LoginRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     */
    public function rules(): array
    {
        return [
            'username' => ['required', 'string'],
            'password' => ['required', 'string'],
        ];
    }

    /**
     * Attempt to authenticate the request's credentials.
     *
     * The username field accepts either:
     * - Username
     * - Email address
     */
    public function authenticate(): void
    {
        $this->ensureIsNotRateLimited();

        $login = trim($this->input('username'));
        $password = $this->input('password');

        /*
        |--------------------------------------------------------------------------
        | Try Username
        |--------------------------------------------------------------------------
        */

        $authenticated = Auth::attempt(
            [
                'username' => $login,
                'password' => $password,
            ],
            $this->boolean('remember')
        );

        /*
        |--------------------------------------------------------------------------
        | Try Email
        |--------------------------------------------------------------------------
        */

        if (! $authenticated) {

            $authenticated = Auth::attempt(
                [
                    'email' => $login,
                    'password' => $password,
                ],
                $this->boolean('remember')
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Authentication Failed
        |--------------------------------------------------------------------------
        */

        if (! $authenticated) {

            RateLimiter::hit($this->throttleKey());

            throw ValidationException::withMessages([
                'username' => trans('auth.failed'),
            ]);
        }

        /*
        |--------------------------------------------------------------------------
        | Authentication Successful
        |--------------------------------------------------------------------------
        */

        RateLimiter::clear($this->throttleKey());
    }

    /**
     * Ensure the login request is not rate limited.
     */
    public function ensureIsNotRateLimited(): void
    {
        if (! RateLimiter::tooManyAttempts($this->throttleKey(), 5)) {
            return;
        }

        event(new Lockout($this));

        $seconds = RateLimiter::availableIn(
            $this->throttleKey()
        );

        throw ValidationException::withMessages([
            'username' => trans('auth.throttle', [
                'seconds' => $seconds,
                'minutes' => ceil($seconds / 60),
            ]),
        ]);
    }

    /**
     * Get the rate limiting throttle key for the request.
     */
    public function throttleKey(): string
    {
        return Str::transliterate(
            Str::lower(
                trim($this->input('username'))
            ) . '|' . $this->ip()
        );
    }
}
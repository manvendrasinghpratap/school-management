<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class ExamSchedule extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'exam_schedules';

    protected $fillable = [
        'examination_id',
        'course_id',
        'class_id',
        'section_id',
        'exam_date',
        'start_time',
        'end_time',
        'room',
    ];

    protected $casts = [
        'examination_id' => 'integer',
        'course_id' => 'integer',
        'class_id' => 'integer',
        'section_id' => 'integer',
        'exam_date' => 'date',
    ];

    public function examination(): BelongsTo
    {
        return $this->belongsTo(
            Examination::class,
            'examination_id'
        );
    }

    public function course(): BelongsTo
    {
        return $this->belongsTo(
            Courses::class,
            'course_id'
        );
    }

    public function classModel(): BelongsTo
    {
        return $this->belongsTo(
            Classes::class,
            'class_id'
        );
    }

    public function section(): BelongsTo
    {
        return $this->belongsTo(
            Section::class,
            'section_id'
        );
    }
}
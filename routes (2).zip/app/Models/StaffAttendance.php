<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class StaffAttendance extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'staff_attendance';

    protected $fillable = [
        'school_id',
        'staff_id',
        'attendance_date',
        'status',
        'check_in',
        'check_out',
        'recorded_by',
        'remarks',
    ];

    protected $casts = [
        'school_id' => 'integer',
        'staff_id' => 'integer',
        'attendance_date' => 'date',
        'recorded_by' => 'integer',
    ];

    public function staff(): BelongsTo
    {
        return $this->belongsTo(
            Staff::class,
            'staff_id'
        );
    }

    public function recordedBy(): BelongsTo
    {
        return $this->belongsTo(
            User::class,
            'recorded_by'
        );
    }
}
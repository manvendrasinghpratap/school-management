<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Alumni extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'alumni';

    protected $fillable = [
        'school_id',
        'student_id',
        'graduation_date',
        'graduation_year',
        'current_occupation',
        'current_employer',
        'phone',
        'email',
        'address',
    ];

    protected function casts(): array
    {
        return [
            'graduation_date' => 'date',
        ];
    }

    public function school(): BelongsTo
    {
        return $this->belongsTo(School::class);
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(Student::class);
    }
    public function alumni(): HasOne
{
    return $this->hasOne(Alumni::class, 'student_id');
}
}
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Courses extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'courses';

    protected $fillable = [
        'school_id',
        'department_id',
        'course_code',
        'name',
        'description',
        'credit_hours',
        'is_compulsory',
        'is_active',
    ];

    protected function casts(): array
    {
        return [
            'credit_hours' => 'decimal:2',
            'is_compulsory' => 'boolean',
            'is_active' => 'boolean',
        ];
    }

    public function school(): BelongsTo
    {
        return $this->belongsTo(School::class);
    }

    public function department(): BelongsTo
    {
        return $this->belongsTo(Department::class);
    }
    public function students(): BelongsToMany
{
    return $this->belongsToMany(
        Student::class,
        'student_courses',
        'course_id',
        'student_id'
    )->withTimestamps();
}
}